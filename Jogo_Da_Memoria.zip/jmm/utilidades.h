#ifndef UTILIDADES_H
#define UTILIDADES_H

void lerLinha(char *buffer, int tamanho);
int lerInt();
void pausar();
int letraParaIndice(char c);

#endif