#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <stdbool.h>

/* Diretivas de compilacao condicional para compatibilidade entre Windows e Linux/Unix */
#ifdef _WIN32
    #include <windows.h>
    #define LIMPAR "cls"              // Comando para limpar tela no Windows
    #define SLEEP(x) Sleep((x)*1000)  // Funcao sleep no Windows (recebe milissegundos)
#else
    #include <unistd.h>
    #define LIMPAR "clear"            // Comando para limpar tela no Linux/Unix
    #define SLEEP(x) sleep(x)         // Funcao sleep no Linux/Unix (recebe segundos)
#endif

/* Estrutura que representa um jogador no jogo */
typedef struct {
    char nome[80];           // Nome do jogador (maximo 80 caracteres)
    int pontos;              // Pontuacao atual do jogador
    int paresEncontrados;    // Quantidade de pares de cartas que o jogador encontrou
} Player;

/* Estrutura para salvar o estado completo do jogo em arquivo */
typedef struct {
    char nomeJogador[80];      // Nome do jogador que salvou o jogo
    int pontos;                // Pontos do jogador no momento do save
    int paresEncontrados;      // Pares encontrados ate o momento
    int tamanho;               // Tamanho do tabuleiro (4, 6, 8 ou 10)
    char tabuleiro[10][10];    // Matriz que guarda todas as cartas (conteudo real)
    char visivelSave[10][10];  // Matriz que guarda o estado visivel (? ou simbolo revelado)
} SaveGame;

/* Variaveis globais compartilhadas entre os modulos */
extern char *simbolos;   // String com os simbolos usados nas cartas
extern char **cartas;    // Matriz dinamica que armazena o tabuleiro real (oculto do jogador)
extern char **visivel;   // Matriz dinamica que armazena o que o jogador ve (? ou revelado)

#endif