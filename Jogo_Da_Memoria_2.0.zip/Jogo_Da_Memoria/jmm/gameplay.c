#include <stdio.h>
#include <stdlib.h>
#include "gameplay.h"
#include "tabuleiro.h"
#include "jogador.h"
#include "save.h"
#include "utilidades.h"
#include "estruturas.h"

/* Funcao principal que controla a logica do jogo da memoria */
void jogar(Player jogadores[], int numJogadores, int tam, bool permitirSave) {
    /* Calcula o total de pares no tabuleiro */
    int totalPares = (tam * tam) / 2;
    int vezDe = 0;  // Indice do jogador atual (0 ou 1)
    
    /* Validacao dos dados dos jogadores para evitar valores incorretos */
    for (int i = 0; i < numJogadores; i++) {
        /* Garante que os pontos estejam em uma faixa valida */
        if (jogadores[i].pontos <= 0 || jogadores[i].pontos > 10000) {
            jogadores[i].pontos = 100;
        }
        /* Garante que os pares encontrados sejam validos */
        if (jogadores[i].paresEncontrados < 0 || jogadores[i].paresEncontrados > 100) {
            jogadores[i].paresEncontrados = 0;
        }
    }
    
    /* Loop principal do jogo - continua ate o fim */
    while (1) {
        Player *atual = &jogadores[vezDe];  // Ponteiro para o jogador atual
        
        /* Verifica Game Over no modo individual (pontos zerados) */
        if (numJogadores == 1 && atual->pontos <= 0) {
            mostrarTabuleiro(tam, jogadores, numJogadores);
            printf("\n%s ficou sem pontos!\n", atual->nome);
            printf("\n*** GAME OVER ***\n");
            if (permitirSave) deletarSave();  // Remove o save se existir
            break;  // Sai do loop
        }
        
        /* Conta quantos pares ja foram encontrados no total */
        int totalEncontrados = 0;
        for (int i = 0; i < numJogadores; i++) {
            totalEncontrados += jogadores[i].paresEncontrados;
        }
        
        /* Verifica se todos os pares foram encontrados (fim de jogo) */
        if (totalEncontrados >= totalPares) {
            mostrarTabuleiro(tam, jogadores, numJogadores);
            printf("\n========== FIM DE JOGO ==========\n");
            
            /* Modo individual - exibe vitoria e pontuacao final */
            if (numJogadores == 1) {
                printf("\n*** VOCE VENCEU! ***\n");
                printf("Pontuacao final: %d pontos\n", jogadores[0].pontos);
                if (permitirSave) deletarSave();
            } else {
                /* Modo multiplayer - exibe pares de cada jogador */
                printf("\n");
                for (int i = 0; i < numJogadores; i++) {
                    printf("%s: %d pares\n", jogadores[i].nome, jogadores[i].paresEncontrados);
                }
                
                /* Determina o vencedor */
                if (jogadores[0].paresEncontrados > jogadores[1].paresEncontrados) {
                    printf("\n*** %s VENCEU! ***\n", jogadores[0].nome);
                } else if (jogadores[1].paresEncontrados > jogadores[0].paresEncontrados) {
                    printf("\n*** %s VENCEU! ***\n", jogadores[1].nome);
                } else {
                    printf("\n*** EMPATE! ***\n");
                }
            }
            break;  // Sai do loop
        }
        
        /* Exibe o tabuleiro atual */
        mostrarTabuleiro(tam, jogadores, numJogadores);
        
        /* No modo individual com save habilitado, oferece opcao de salvar */
        if (numJogadores == 1 && permitirSave) {
            printf("Digite 'S' para salvar e sair, ou pressione ENTER para continuar\n");
            char buffer[10];
            lerLinha(buffer, sizeof(buffer));
            
            /* Se o jogador digitar S, salva e sai */
            if (buffer[0] == 'S' || buffer[0] == 's') {
                salvarJogo(&jogadores[0], tam);
                /* NAO destrói o tabuleiro aqui - será destruído pela função chamadora */
                pausar();
                return;
            }
        }
        
        printf("Vez de: %s\n\n", atual->nome);
        
        int lin1, col1, lin2, col2;  // Coordenadas das duas cartas escolhidas
        
        /* Jogador escolhe a primeira carta */
        lerPosicao(tam, &lin1, &col1, "Escolha a PRIMEIRA carta:");
        
        /* Revela a primeira carta */
        visivel[lin1][col1] = cartas[lin1][col1];
        mostrarTabuleiro(tam, jogadores, numJogadores);
        printf("Primeira: [%c] em %c%d\n", cartas[lin1][col1], 'a' + lin1, col1);
        SLEEP(1);  // Pausa para o jogador ver
        
        /* Loop para escolher a segunda carta (deve ser diferente da primeira) */
        while (1) {
            lerPosicao(tam, &lin2, &col2, "\nEscolha a SEGUNDA carta:");
            
            /* Verifica se o jogador escolheu a mesma carta */
            if (lin1 == lin2 && col1 == col2) {
                printf("\nEscolha uma carta DIFERENTE!\n");
                SLEEP(1);
                mostrarTabuleiro(tam, jogadores, numJogadores);
                printf("Primeira: [%c] em %c%d\n", cartas[lin1][col1], 'a' + lin1, col1);
                continue;  // Volta ao inicio do loop
            }
            break;  // Carta valida, sai do loop
        }
        
        /* Revela a segunda carta */
        visivel[lin2][col2] = cartas[lin2][col2];
        mostrarTabuleiro(tam, jogadores, numJogadores);
        printf("Primeira: [%c] em %c%d\n", cartas[lin1][col1], 'a' + lin1, col1);
        printf("Segunda:  [%c] em %c%d\n", cartas[lin2][col2], 'a' + lin2, col2);
        SLEEP(2);  // Pausa para o jogador ver ambas as cartas
        
        /* Verifica se as cartas formam um par */
        int acertou = 0;
        if (cartas[lin1][col1] == cartas[lin2][col2]) {
            /* Par correto - incrementa pares e mantem as cartas reveladas */
            printf("\n*** ACERTOU! ***\n");
            atual->paresEncontrados++;
            pausar();
            acertou = 1;
        } else {
            /* Par incorreto */
            if (numJogadores == 1) {
                /* Modo individual - perde pontos */
                printf("\n*** ERROU! -10 pontos ***\n");
                atual->pontos -= 10;
            } else {
                /* Modo multiplayer - apenas informa erro */
                printf("\n*** ERROU! ***\n");
            }
            /* Esconde as cartas novamente */
            visivel[lin1][col1] = '?';
            visivel[lin2][col2] = '?';
            pausar();
        }
        
        /* No multiplayer, se errou, passa a vez para o outro jogador */
        if (!acertou && numJogadores > 1) {
            vezDe = 1 - vezDe;  // Alterna entre 0 e 1
        }
    }
}

/* Funcao que gerencia o modo de jogo individual */
void modoIndividual() {
    system(LIMPAR);  // Limpa a tela
    
    char nome[80];
    printf("\n========== MODO INDIVIDUAL ==========\n\n");
    printf("Nome do jogador: ");
    lerLinha(nome, sizeof(nome));  // Le o nome do jogador
    
    /* Carrega ou cria o jogador */
    Player jogador = carregarJogador(nome);
    
    /* Reseta pontos e pares para uma nova partida */
    jogador.pontos = 0;
    jogador.paresEncontrados = 0;
    
    /* Menu de selecao de dificuldade */
    printf("\n=== DIFICULDADE ===\n");
    printf("1 - Facil (4x4)\n");
    printf("2 - Normal (6x6)\n");
    printf("3 - Dificil (8x8)\n");
    printf("4 - Impossivel (10x10)\n");
    printf("\nEscolha: ");
    
    int opcao = lerInt();
    int tam;  // Tamanho do tabuleiro
    
    /* Define o tamanho baseado na opcao escolhida */
    switch (opcao) {
        case 1: tam = 4; break;   // 4x4 = 16 cartas (8 pares)
        case 2: tam = 6; break;   // 6x6 = 36 cartas (18 pares)
        case 3: tam = 8; break;   // 8x8 = 64 cartas (32 pares)
        case 4: tam = 10; break;  // 10x10 = 100 cartas (50 pares)
        default:
            printf("Opcao invalida!\n");
            SLEEP(2);
            return;  // Sai da funcao se opcao invalida
    }
    
    /* Exibe as regras do modo individual */
    system(LIMPAR);
    printf("\n=== REGRAS ===\n");
    printf("- Voce comeca com 100 pontos\n");
    printf("- Acerto: mantem pontos\n");
    printf("- Erro: -10 pontos\n");
    printf("- Zerar = Game Over\n");
    pausar();
    
    /* Cria o tabuleiro e inicia o jogo */
    criarTabuleiro(tam);
    mostrarMemorizacao(tam);  // Mostra todas as cartas por 15 segundos
    jogar(&jogador, 1, tam, true);  // Inicia o jogo (1 jogador, save habilitado)
    
    /* Se o jogador terminou com pontos positivos, tenta salvar recorde */
    if (jogador.pontos > 0) {
        salvarRecorde(&jogador);
    }
    
    /* Libera a memoria do tabuleiro */
    destruirTabuleiro(tam);
    pausar();
}

/* Funcao que gerencia o modo de jogo para 2 jogadores */
void modoMultiplayer() {
    system(LIMPAR);
    
    Player jogadores[2] = {0};  // Array com dois jogadores, inicializado com zeros
    
    printf("\n========== MODO 2 JOGADORES ==========\n\n");
    
    /* Le o nome do primeiro jogador */
    printf("Nome do Jogador 1: ");
    lerLinha(jogadores[0].nome, sizeof(jogadores[0].nome));
    jogadores[0].pontos = 100;  // No multiplayer os pontos nao sao usados
    jogadores[0].paresEncontrados = 0;
    
    /* Le o nome do segundo jogador */
    printf("Nome do Jogador 2: ");
    lerLinha(jogadores[1].nome, sizeof(jogadores[1].nome));
    jogadores[1].pontos = 100;
    jogadores[1].paresEncontrados = 0;
    
    /* Menu de selecao de dificuldade */
    printf("\n=== DIFICULDADE ===\n");
    printf("1 - Facil (4x4)\n");
    printf("2 - Normal (6x6)\n");
    printf("3 - Dificil (8x8)\n");
    printf("4 - Impossivel (10x10)\n");
    printf("\nEscolha: ");
    
    int opcao = lerInt();
    int tam;
    
    /* Define o tamanho do tabuleiro */
    switch (opcao) {
        case 1: tam = 4; break;
        case 2: tam = 6; break;
        case 3: tam = 8; break;
        case 4: tam = 10; break;
        default:
            printf("Opcao invalida!\n");
            SLEEP(2);
            return;
    }
    
    /* Exibe as regras do modo multiplayer */
    system(LIMPAR);
    printf("\n=== REGRAS - 2 JOGADORES ===\n");
    printf("- Nao ha pontos neste modo\n");
    printf("- Acerto: +1 par e joga de novo\n");
    printf("- Erro: passa a vez\n");
    printf("- Vence quem fizer mais pares\n");
    pausar();
    
    /* Cria o tabuleiro e inicia o jogo */
    criarTabuleiro(tam);
    mostrarMemorizacao(tam);
    jogar(jogadores, 2, tam, false);  // 2 jogadores, save desabilitado
    /* Libera a memoria do tabuleiro */
    destruirTabuleiro(tam);
    pausar();
}

/* Funcao que carrega e continua um jogo salvo anteriormente */
void continuarJogo() {
    system(LIMPAR);
    
    /* Verifica se existe um save */
    if (!existeSave()) {
        printf("\nNenhum jogo salvo encontrado!\n");
        pausar();
        return;
    }
    
    Player jogador;
    int tam;
    
    /* Tenta carregar o jogo salvo (ja cria o tabuleiro internamente) */
    if (!carregarJogo(&jogador, &tam)) {
        printf("\nErro ao carregar o jogo salvo!\n");
        pausar();
        return;
    }
    
    /* Exibe informacoes do jogo carregado */
    printf("\n========== JOGO CARREGADO ==========\n");
    printf("Jogador: %s\n", jogador.nome);
    printf("Pontos: %d\n", jogador.pontos);
    printf("Pares encontrados: %d\n", jogador.paresEncontrados);
    printf("\nVamos relembrar as cartas...\n");
    pausar();
    
    /* Backup dos dados do jogador (para restaurar apos a memorizacao) */
    int pontosBackup = jogador.pontos;
    int paresBackup = jogador.paresEncontrados;
    
    /* Cria backup temporario da matriz visivel */
    char **visivelTemp = malloc(tam * sizeof(char*));
    for (int i = 0; i < tam; i++) {
        visivelTemp[i] = malloc(tam * sizeof(char));
        for (int j = 0; j < tam; j++) {
            visivelTemp[i][j] = visivel[i][j];  // Copia o estado atual
        }
    }
    
    /* Mostra todas as cartas por 15 segundos para o jogador relembrar */
    mostrarMemorizacao(tam);
    
    /* Restaura o estado visivel anterior (cartas que ja estavam reveladas) */
    for (int i = 0; i < tam; i++) {
        for (int j = 0; j < tam; j++) {
            visivel[i][j] = visivelTemp[i][j];  // Restaura o estado original
        }
        free(visivelTemp[i]);  // Libera memoria da linha
    }
    free(visivelTemp);  // Libera memoria do array de ponteiros
    
    /* Restaura os dados do jogador */
    jogador.pontos = pontosBackup;
    jogador.paresEncontrados = paresBackup;
    
    /* Continua o jogo de onde parou */
    jogar(&jogador, 1, tam, true);
    
    /* Se terminou com pontos positivos, tenta salvar recorde */
    if (jogador.pontos > 0) {
        salvarRecorde(&jogador);
    }
    
    /* Libera a memoria do tabuleiro (agora sempre destrói após jogar) */
    destruirTabuleiro(tam);
    pausar();
}