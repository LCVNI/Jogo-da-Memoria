/* ===== gameplay.h ===== */
#ifndef GAMEPLAY_H
#define GAMEPLAY_H

#include "estruturas.h"

/* Funcao principal que controla o fluxo do jogo */
void jogar(Player jogadores[], int numJogadores, int tam, bool permitirSave);

/* Funcao que gerencia o modo de jogo individual */
void modoIndividual();

/* Funcao que gerencia o modo de jogo para 2 jogadores */
void modoMultiplayer();

/* Funcao que continua um jogo previamente salvo */
void continuarJogo();

#endif
