#include <stdio.h>
#include <string.h>
#include "jogador.h"
#include "estruturas.h"

/* Funcao que busca um jogador no arquivo ou cria um novo */
Player carregarJogador(const char *nome) {
    Player p;
    strcpy(p.nome, nome);        // Copia o nome para a estrutura
    p.pontos = 0;                // Inicializa pontos
    p.paresEncontrados = 0;      // Inicializa pares encontrados
    
    /* Tenta abrir o arquivo de jogadores */
    FILE *f = fopen("lista.txt", "r");
    if (f) {
        char nomeLido[80];
        int pontosLido;
        
        /* Le cada linha do arquivo ate encontrar o jogador ou acabar o arquivo */
        while (fscanf(f, "%79s %d", nomeLido, &pontosLido) == 2) {
            /* Se encontrou o jogador, carrega seus dados */
            if (strcmp(nome, nomeLido) == 0) {
                p.pontos = pontosLido;
                printf("\nBem-vindo de volta, %s!\n", nome);
                printf("Seu recorde: %d pontos\n", pontosLido);
                fclose(f);
                return p;  // Retorna jogador existente
            }
        }
        fclose(f);
    }
    
    /* Se nao encontrou o jogador, retorna um novo */
    printf("\nNovo jogador criado: %s\n", nome);
    return p;
}

/* Funcao que salva ou atualiza o recorde de pontuacao de um jogador */
void salvarRecorde(Player *p) {
    /* Abre o arquivo original para leitura */
    FILE *f = fopen("lista.txt", "r");
    /* Cria arquivo temporario para escrita */
    FILE *temp = fopen("temp.txt", "w");
    
    if (!temp) return;  // Se nao conseguiu criar o temporario, sai da funcao
    
    char nomeLido[80];
    int pontosLido;
    bool encontrado = false;
    
    /* Se o arquivo original existe, processa todos os jogadores */
    if (f) {
        while (fscanf(f, "%79s %d", nomeLido, &pontosLido) == 2) {
            /* Se encontrou o jogador atual */
            if (strcmp(p->nome, nomeLido) == 0) {
                /* Verifica se a pontuacao atual e maior que o recorde anterior */
                if (p->pontos > pontosLido) {
                    fprintf(temp, "%s %d\n", p->nome, p->pontos);
                    printf("\n*** NOVO RECORDE! %d -> %d pontos ***\n", pontosLido, p->pontos);
                } else {
                    /* Mantem o recorde antigo se for maior */
                    fprintf(temp, "%s %d\n", nomeLido, pontosLido);
                }
                encontrado = true;
            } else {
                /* Copia os outros jogadores sem alteracao */
                fprintf(temp, "%s %d\n", nomeLido, pontosLido);
            }
        }
        fclose(f);
    }
    
    /* Se o jogador nao estava no arquivo, adiciona ele */
    if (!encontrado) {
        fprintf(temp, "%s %d\n", p->nome, p->pontos);
    }
    
    fclose(temp);
    
    /* Substitui o arquivo original pelo temporario atualizado */
    remove("lista.txt");
    rename("temp.txt", "lista.txt");
}

/* Funcao que exibe o ranking dos 10 melhores jogadores */
void mostrarRanking() {
    FILE *f = fopen("lista.txt", "r");
    if (!f) {
        printf("\nNenhum jogador cadastrado ainda!\n");
        return;
    }
    
    Player lista[100];  // Array para armazenar ate 100 jogadores
    int total = 0;
    
    /* Le todos os jogadores do arquivo */
    while (fscanf(f, "%79s %d", lista[total].nome, &lista[total].pontos) == 2) {
        total++;
        if (total >= 100) break;  // Limite de 100 jogadores
    }
    fclose(f);
    
    /* Ordena os jogadores por pontuacao (bubble sort) */
    for (int i = 0; i < total - 1; i++) {
        for (int j = 0; j < total - i - 1; j++) {
            /* Se o jogador atual tem menos pontos que o proximo, troca */
            if (lista[j].pontos < lista[j+1].pontos) {
                Player temp = lista[j];
                lista[j] = lista[j+1];
                lista[j+1] = temp;
            }
        }
    }
    
    /* Exibe o top 10 */
    printf("\n========== TOP 10 ==========\n\n");
    int limite = (total < 10) ? total : 10;  // Mostra ate 10 ou menos se houver menos jogadores
    for (int i = 0; i < limite; i++) {
        printf("%2d. %-20s %d pontos\n", i+1, lista[i].nome, lista[i].pontos);
    }
}