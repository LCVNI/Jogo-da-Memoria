/* ===== jogador.h ===== */
#ifndef JOGADOR_H
#define JOGADOR_H

#include "estruturas.h"

/* Carrega os dados de um jogador existente ou cria um novo */
Player carregarJogador(const char *nome);

/* Salva o recorde de pontuacao do jogador no arquivo */
void salvarRecorde(Player *p);

/* Exibe o ranking dos 10 melhores jogadores */
void mostrarRanking();

#endif

