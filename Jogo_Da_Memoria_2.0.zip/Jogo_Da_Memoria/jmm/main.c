#include <stdio.h>
#include <stdlib.h>
#include "estruturas.h"
#include "utilidades.h"
#include "tabuleiro.h"
#include "jogador.h"
#include "save.h"
#include "gameplay.h"

/* Definicao das variaveis globais declaradas em estruturas.h */
char *simbolos = "ZWXP@$C#89F2HGM";  // String com 15 simbolos diferentes para as cartas
char **cartas = NULL;                 // Matriz dinamica - armazena o tabuleiro real (oculto)
char **visivel = NULL;                // Matriz dinamica - armazena o que o jogador ve

/* Funcao principal do programa - ponto de entrada */
int main() {
    int opcao;  // Armazena a opcao escolhida pelo usuario no menu
    
    /* Loop principal do menu - continua ate o usuario escolher sair */
    do {
        system(LIMPAR);  // Limpa a tela do terminal
        
        /* Exibe o cabecalho do menu */
        printf("\n================================\n");
        printf("      JOGO DA MEMORIA\n");
        printf("================================\n");
        
        /* Verifica se existe um jogo salvo para ajustar o menu */
        if (existeSave()) {
            /* Menu com opcao de continuar jogo salvo */
            printf("1 - Continuar jogo salvo\n");
            printf("2 - Novo jogo individual\n");
            printf("3 - Modo 2 Jogadores\n");
            printf("4 - Ranking\n");
            printf("5 - Sair\n");
        } else {
            /* Menu sem opcao de continuar (nao ha save) */
            printf("1 - Modo Individual\n");
            printf("2 - Modo 2 Jogadores\n");
            printf("3 - Ranking\n");
            printf("4 - Sair\n");
        }
        
        /* Le a opcao do usuario */
        printf("\nEscolha: ");
        opcao = lerInt();
        
        /* Processa a opcao escolhida - menu diferente se ha save ou nao */
        if (existeSave()) {
            /* Menu quando existe save - opcoes numeradas de 1 a 5 */
            switch (opcao) {
                case 1:
                    continuarJogo();      // Carrega e continua o jogo salvo
                    break;
                case 2:
                    modoIndividual();     // Inicia um novo jogo individual
                    break;
                case 3:
                    modoMultiplayer();    // Inicia um jogo para 2 jogadores
                    break;
                case 4:
                    system(LIMPAR);
                    mostrarRanking();     // Exibe o ranking dos melhores jogadores
                    pausar();
                    break;
                case 5:
                    printf("\nObrigado por jogar!\n");  // Mensagem de despedida
                    break;
                default:
                    printf("\nOpcao invalida!\n");
                    SLEEP(1);
            }
        } else {
            /* Menu quando nao existe save - opcoes numeradas de 1 a 4 */
            switch (opcao) {
                case 1:
                    modoIndividual();     // Inicia um novo jogo individual
                    break;
                case 2:
                    modoMultiplayer();    // Inicia um jogo para 2 jogadores
                    break;
                case 3:
                    system(LIMPAR);
                    mostrarRanking();     // Exibe o ranking dos melhores jogadores
                    pausar();
                    break;
                case 4:
                    printf("\nObrigado por jogar!\n");  // Mensagem de despedida
                    break;
                default:
                    printf("\nOpcao invalida!\n");
                    SLEEP(1);
            }
        }
        
    /* Continua o loop enquanto o usuario nao escolher a opcao de sair */
    /* Se ha save: continua ate opcao 5, se nao ha save: continua ate opcao 4 */
    } while ((existeSave() && opcao != 5) || (!existeSave() && opcao != 4));
    
    return 0;  // Retorna 0 indicando execucao bem-sucedida
}