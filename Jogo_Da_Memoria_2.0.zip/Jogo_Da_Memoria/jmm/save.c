#include <stdio.h>
#include <string.h>
#include "save.h"
#include "tabuleiro.h"
#include "estruturas.h"

/* Funcao que verifica se existe um arquivo de jogo salvo */
bool existeSave() {
    /* Tenta abrir o arquivo de save em modo leitura binaria */
    FILE *f = fopen("savegame.dat", "rb");
    if (f) {
        fclose(f);      // Se conseguiu abrir, fecha o arquivo
        return true;    // Retorna verdadeiro (arquivo existe)
    }
    return false;       // Retorna falso (arquivo nao existe)
}

/* Funcao que salva o estado completo do jogo em arquivo binario */
void salvarJogo(Player *jogador, int tam) {
    SaveGame save;  // Estrutura temporaria para armazenar os dados
    
    /* Copia os dados do jogador para a estrutura de save */
    strcpy(save.nomeJogador, jogador->nome);
    save.pontos = jogador->pontos;
    save.paresEncontrados = jogador->paresEncontrados;
    save.tamanho = tam;
    
    /* Copia todo o tabuleiro (cartas reais e cartas visiveis) */
    for (int i = 0; i < tam; i++) {
        for (int j = 0; j < tam; j++) {
            save.tabuleiro[i][j] = cartas[i][j];        // Salva as cartas reais
            save.visivelSave[i][j] = visivel[i][j];     // Salva o estado visivel
        }
    }
    
    /* Abre o arquivo em modo escrita binaria e salva a estrutura */
    FILE *f = fopen("savegame.dat", "wb");
    if (f) {
        fwrite(&save, sizeof(SaveGame), 1, f);  // Escreve a estrutura inteira de uma vez
        fclose(f);
        printf("\nJogo salvo com sucesso!\n");
    } else {
        printf("\nErro ao salvar o jogo!\n");
    }
}

/* Funcao que carrega um jogo salvo do arquivo */
bool carregarJogo(Player *jogador, int *tam) {
    /* Tenta abrir o arquivo de save em modo leitura binaria */
    FILE *f = fopen("savegame.dat", "rb");
    if (!f) {
        return false;  // Se nao conseguiu abrir, retorna falso
    }
    
    SaveGame save;  // Estrutura para receber os dados
    
    /* Le a estrutura completa do arquivo */
    if (fread(&save, sizeof(SaveGame), 1, f) != 1) {
        fclose(f);
        return false;  // Se nao conseguiu ler, retorna falso
    }
    fclose(f);
    
    /* Restaura os dados do jogador */
    strcpy(jogador->nome, save.nomeJogador);
    jogador->pontos = save.pontos;
    jogador->paresEncontrados = save.paresEncontrados;
    *tam = save.tamanho;
    
    /* Cria o tabuleiro com o tamanho salvo */
    criarTabuleiro(*tam);
    
    /* Restaura o estado completo do tabuleiro */
    for (int i = 0; i < *tam; i++) {
        for (int j = 0; j < *tam; j++) {
            cartas[i][j] = save.tabuleiro[i][j];        // Restaura as cartas reais
            visivel[i][j] = save.visivelSave[i][j];     // Restaura o estado visivel
        }
    }
    
    return true;  // Retorna verdadeiro (carregamento bem-sucedido)
}

/* Funcao que deleta o arquivo de save */
void deletarSave() {
    remove("savegame.dat");  // Remove o arquivo do sistema
}