/* ===== save.h ===== */
#ifndef SAVE_H
#define SAVE_H

#include "estruturas.h"

/* Verifica se existe um arquivo de save */
bool existeSave();

/* Salva o estado atual do jogo em arquivo */
void salvarJogo(Player *jogador, int tam);

/* Carrega um jogo salvo do arquivo */
bool carregarJogo(Player *jogador, int *tam);

/* Deleta o arquivo de save */
void deletarSave();

#endif
