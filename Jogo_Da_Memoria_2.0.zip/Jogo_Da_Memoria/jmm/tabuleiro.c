#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "tabuleiro.h"
#include "utilidades.h"
#include "estruturas.h"

/* Funcao que cria o tabuleiro do jogo e distribui as cartas aleatoriamente */
void criarTabuleiro(int tam) {
    /* Aloca memoria para as matrizes bidimensionais (linhas) */
    cartas = malloc(tam * sizeof(char*));
    visivel = malloc(tam * sizeof(char*));
    
    /* Aloca memoria para cada linha e inicializa os valores */
    for (int i = 0; i < tam; i++) {
        cartas[i] = malloc(tam * sizeof(char));     // Aloca uma linha para cartas reais
        visivel[i] = malloc(tam * sizeof(char));    // Aloca uma linha para cartas visiveis
        memset(cartas[i], 0, tam);                  // Inicializa cartas com valor 0
        memset(visivel[i], '?', tam);               // Inicializa visivel com '?'
    }
    
    /* Inicializa gerador de numeros aleatorios com o tempo atual */
    srand(time(NULL));
    int idx = 0;  // Indice do simbolo atual
    
    /* Distribui os simbolos aleatoriamente no tabuleiro */
    for (int count = 0; count < tam * tam; count++) {
        int i, j;
        /* Procura uma posicao vazia aleatoria */
        do {
            i = rand() % tam;  // Linha aleatoria
            j = rand() % tam;  // Coluna aleatoria
        } while (cartas[i][j] != 0);  // Repete se a posicao ja esta ocupada
        
        /* Coloca o simbolo atual na posicao encontrada */
        cartas[i][j] = simbolos[idx];
        
        /* A cada duas cartas, avanca para o proximo simbolo (para criar pares) */
        if (count % 2 == 1) idx++;
        /* Se acabaram os simbolos, volta ao inicio */
        if (idx >= (int)strlen(simbolos)) idx = 0;
    }
}

/* Funcao que libera toda a memoria alocada para o tabuleiro */
void destruirTabuleiro(int tam) {
    /* Libera cada linha individualmente */
    for (int i = 0; i < tam; i++) {
        free(cartas[i]);
        free(visivel[i]);
    }
    /* Libera os arrays de ponteiros */
    free(cartas);
    free(visivel);
}

/* Funcao que exibe o tabuleiro na tela com informacoes dos jogadores */
void mostrarTabuleiro(int tam, Player jogadores[], int numJogadores) {
    system(LIMPAR);  // Limpa a tela do terminal
    
    printf("\n========== JOGO DA MEMORIA ==========\n\n");
    
    /* Exibe informacoes de cada jogador */
    for (int p = 0; p < numJogadores; p++) {
        printf("%s: %d pontos", jogadores[p].nome, jogadores[p].pontos);
        /* No modo multiplayer, mostra tambem os pares encontrados */
        if (numJogadores > 1) {
            printf(" (%d pares)", jogadores[p].paresEncontrados);
        }
        printf("\n");
    }
    printf("\n");
    
    /* Exibe os numeros das colunas (cabecalho) */
    printf("    ");
    for (int j = 0; j < tam; j++) {
        printf(" %d  ", j);
    }
    printf("\n");
    
    /* Exibe o tabuleiro linha por linha */
    for (int i = 0; i < tam; i++) {
        printf(" %c  ", 'a' + i);  // Exibe a letra da linha (a, b, c, ...)
        for (int j = 0; j < tam; j++) {
            printf("[%c] ", visivel[i][j]);  // Exibe cada carta (? ou simbolo)
        }
        printf("\n");
    }
    printf("\n");
}

/* Funcao que mostra todas as cartas por 15 segundos para o jogador memorizar */
void mostrarMemorizacao(int tam) {
    printf("\n========== MEMORIZE! ==========\n\n");
    
    /* Exibe os numeros das colunas */
    printf("    ");
    for (int j = 0; j < tam; j++) {
        printf(" %d  ", j);
    }
    printf("\n");
    
    /* Exibe todas as cartas reveladas */
    for (int i = 0; i < tam; i++) {
        printf(" %c  ", 'a' + i);
        for (int j = 0; j < tam; j++) {
            printf("[%c] ", cartas[i][j]);  // Mostra os simbolos reais
        }
        printf("\n");
    }
    
    /* Contagem regressiva de 15 segundos */
    printf("\n");
    for (int i = 15; i > 0; i--) {
        printf("\rEscondendo em %d...", i);  // \r volta ao inicio da linha
        fflush(stdout);                      // Forca a exibicao imediata
        SLEEP(1);                            // Aguarda 1 segundo
    }
    printf("\rEscondendo em 0...\n");
    SLEEP(1);
}

/* Funcao que le a posicao de uma carta escolhida pelo jogador */
void lerPosicao(int tam, int *lin, int *col, const char *msg) {
    char buffer[100];
    char letra;
    
    /* Loop ate o jogador fornecer uma posicao valida */
    while (1) {
        /* Le a linha (letra) */
        printf("%s\n", msg);
        printf("Linha (a-%c): ", 'a' + tam - 1);
        lerLinha(buffer, sizeof(buffer));
        letra = buffer[0];
        
        /* Converte a letra em indice numerico */
        *lin = letraParaIndice(letra);
        
        /* Verifica se a entrada e uma letra valida */
        if (*lin < 0 || *lin >= tam) {
            printf("Entrada invalida! Digite apenas letras de 'a' ate '%c'\n", 'a' + tam - 1);
            SLEEP(1);
            continue;  // Volta ao inicio do loop
        }
        
        /* Le a coluna (numero) */
        printf("Coluna (0-%d): ", tam - 1);
        *col = lerInt();  // lerInt() ja valida que e numero
        
        /* Verifica se a coluna esta dentro dos limites do tabuleiro */
        if (*col < 0 || *col >= tam) {
            printf("\nPosicao invalida!\n");
            SLEEP(1);
            continue;  // Volta ao inicio do loop
        }
        
        /* Verifica se a carta ja foi descoberta */
        if (visivel[*lin][*col] != '?') {
            printf("\nCarta ja descoberta!\n");
            SLEEP(1);
            continue;  // Volta ao inicio do loop
        }
        
        break;  // Posicao valida, sai do loop
    }
}