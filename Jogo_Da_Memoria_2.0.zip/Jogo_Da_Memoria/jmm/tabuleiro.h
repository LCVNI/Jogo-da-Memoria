/* ===== tabuleiro.h ===== */
#ifndef TABULEIRO_H
#define TABULEIRO_H

#include "estruturas.h"

/* Cria e inicializa o tabuleiro do jogo com cartas embaralhadas */
void criarTabuleiro(int tam);

/* Libera a memoria alocada para o tabuleiro */
void destruirTabuleiro(int tam);

/* Exibe o tabuleiro atual na tela com as cartas visiveis */
void mostrarTabuleiro(int tam, Player jogadores[], int numJogadores);

/* Mostra todas as cartas por 15 segundos para memorizacao */
void mostrarMemorizacao(int tam);

/* Le a posicao de uma carta escolhida pelo jogador */
void lerPosicao(int tam, int *lin, int *col, const char *msg);

#endif