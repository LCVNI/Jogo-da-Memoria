#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "utilidades.h"

/* Funcao que le uma linha de texto do usuario de forma segura */
void lerLinha(char *buffer, int tamanho) {
    fgets(buffer, tamanho, stdin);              // Le a linha incluindo o \n
    buffer[strcspn(buffer, "\n")] = '\0';       // Remove o caractere de nova linha
}

/* Funcao que verifica se uma string contem apenas digitos numericos */
int ehNumero(const char *str) {
    /* String vazia nao e numero */
    if (str[0] == '\0') return 0;
    
    /* Permite sinal negativo no inicio */
    int i = 0;
    if (str[0] == '-' || str[0] == '+') {
        i = 1;
        /* Sinal sozinho nao e numero */
        if (str[1] == '\0') return 0;
    }
    
    /* Verifica se todos os caracteres restantes sao digitos */
    while (str[i] != '\0') {
        if (!isdigit(str[i])) {
            return 0;  // Encontrou caractere nao-digito
        }
        i++;
    }
    
    return 1;  // Todos os caracteres sao digitos
}

/* Funcao que le um numero inteiro digitado pelo usuario com validacao */
int lerInt() {
    char buffer[100];                           // Buffer temporario para armazenar a entrada
    
    /* Loop ate o usuario digitar um numero valido */
    while (1) {
        lerLinha(buffer, sizeof(buffer));       // Le a linha como string
        
        /* Verifica se a entrada contem apenas digitos */
        if (ehNumero(buffer)) {
            return atoi(buffer);                // Converte a string para inteiro e retorna
        } else {
            /* Entrada invalida - solicita novamente */
            printf("Entrada invalida! Digite apenas numeros: ");
        }
    }
}

/* Funcao que pausa a execucao ate o usuario pressionar ENTER */
void pausar() {
    printf("\nPressione ENTER para continuar...");
    getchar();                                   // Aguarda o usuario pressionar ENTER
}

/* Funcao que converte uma letra em seu indice correspondente */
int letraParaIndice(char c) {
    if (c >= 'a' && c <= 'z') return c - 'a';   // Letra minuscula: retorna 0-25
    if (c >= 'A' && c <= 'Z') return c - 'A';   // Letra maiuscula: retorna 0-25
    return -1;                                   // Caractere invalido: retorna -1
}