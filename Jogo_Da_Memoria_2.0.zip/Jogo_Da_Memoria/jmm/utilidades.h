/* ===== utilidades.h ===== */
#ifndef UTILIDADES_H
#define UTILIDADES_H

/* Funcao para ler uma linha completa de entrada do usuario */
void lerLinha(char *buffer, int tamanho);

/* Funcao para ler um numero inteiro do usuario com validacao */
int lerInt();

/* Funcao para pausar a execucao ate o usuario pressionar ENTER */
void pausar();

/* Funcao para converter uma letra (a-z ou A-Z) em indice numerico (0-25) */
int letraParaIndice(char c);

/* Funcao para verificar se uma string contem apenas digitos */
int ehNumero(const char *str);

#endif